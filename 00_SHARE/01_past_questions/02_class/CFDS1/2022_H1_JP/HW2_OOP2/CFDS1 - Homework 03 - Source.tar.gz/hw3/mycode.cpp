#include <cstdlib>
#include <iostream>
#include <math.h>
#include "mycode.h"

// Fill in
