#pragma once

#include <string>

void wordcount(std::string sentences);
