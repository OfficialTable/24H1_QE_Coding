#include <cstdlib>
#include <iostream>
#include <math.h>

int main() {
  unsigned int start_num;
  unsigned int end_num;

  std::cout << "Find prime number within a range:\n";
  std::cout << "--------------------------------------\n";
  std::cout << "-> The start of the range: ";
  // TODO: set start_num
  std::cout << "-> The end of the range: ";
  // TODO: set end_num

  std::cout << "\nThe prime numbers between " << start_num
            << " and " << end_num << " are:" << std::endl;

  // TODO: print prime numbers

  return EXIT_SUCCESS;
}
