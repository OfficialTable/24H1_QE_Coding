#include "wordcount.h"
#include <iostream>
#include <sstream>

#define MAX_WORDS 30

void wordcount(std::string sentences) {
  // store number of total words
  unsigned int total_words = 0;

  // TODO: calculate word counts

  std::cout << "Total number of words: " << total_words << std::endl;

  // TODO: print number of appearances for each word
}
