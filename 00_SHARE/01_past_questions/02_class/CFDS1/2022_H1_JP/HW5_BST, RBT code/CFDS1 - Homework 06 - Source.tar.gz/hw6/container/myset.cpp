#include "myset.h"

void MySet::Insert(int data) {
  // TODO: insert 'data' into set
}

void MySet::Erase(int data) {
  // TODO: erase 'data' from set
}

bool MySet::Find(int data) {
  // TODO: return true if 'data' exists in the set
  return false;
}

size_t MySet::Size() {
  // TODO: return number of elements in the set
}
